package com.example.swipingfunction.activites


import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.SwipingFunction.R
import com.google.android.material.tabs.TabLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.example.swipingfunction.fragments.MatchesFragment
import com.example.swipingfunction.fragments.ProfileFragment
import com.example.swipingfunction.fragments.SwipeFragment
import kotlinx.android.synthetic.main.activity_main.*



class PIPELINEActivity : AppCompatActivity(), TinderCallback {

    private val firebaseAuth = FirebaseAuth.getInstance()
    private val userId = firebaseAuth.currentUser?.uid
    private lateinit var userDatabase: DatabaseReference
    private lateinit var chatDatabase: DatabaseReference


    private var profileFragment: ProfileFragment? = null
    private var swipeFragment: SwipeFragment? = null
    private var matchesFragment: MatchesFragment? = null

    private var profileTab: TabLayout.Tab? = null
    private var swipeTab: TabLayout.Tab? = null
    private var matchesTab: TabLayout.Tab? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swipeTab = navigationTabs.newTab()

        swipeTab?.icon = ContextCompat.getDrawable(  this, R.drawable.tab_swipe)

        navigationTabs.addTab(swipeTab!!)

        navigationTabs.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener {
            override fun onTabReselected(tab: TabLayout.Tab?) {
                onTabSelected(tab)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when(tab) {
                    swipeTab -> {
                        if(swipeFragment == null){
                            swipeFragment = SwipeFragment()
                            swipeFragment!!.setCallback(this@PIPELINEActivity)
                        }
                        replaceFragment(swipeFragment!!)
                    }
                }
            }

        })


    }

    fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentcontainer, fragment)
            .commit()
    }


    override fun onSignout() {
        firebaseAuth.signOut()
        //startActivity(StartupActivity.newIntent(this))
        finish()
    }

    override fun onGetUserId(): String = userId!!

    override fun getUserDatabase(): DatabaseReference = userDatabase

    override fun getChatDatabase(): DatabaseReference = chatDatabase


    override fun profileComplete() {
        swipeTab?.select()
    }

    override fun startActivityForPhoto() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
       // startActivityForResult(intent, REQUEST_CODE_PHOTO)
    }
    companion object {
        fun newIntent(context: Context?) = Intent(context, PIPELINEActivity::class.java)
    }
}


